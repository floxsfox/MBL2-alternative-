# Build lewat GitHub Web (tanpa PC)

1. Buat repo baru, lalu **Add file > Upload files** dan upload `MBloader-Source.zip` (jangan di-extract) ke root repo.
2. **Add file > Create new file**, nama: `.github/workflows/build-mbloader.yml`, tempel isi file `build-mbloader.yml`, Commit.
3. Tab **Actions** > **Build MBloader** > (kalau belum jalan sendiri) **Run workflow**.
4. Setelah hijau, buka run-nya, scroll ke **Artifacts**, download **MBloader**. Isinya `mbloader.levipack` + folder `mbloader/`.
5. LeviLauncher > Mods > Add Mod > pilih `mbloader.levipack`.

Workflow ini juga menjalankan uji logika di runner sebelum build Android. Kalau merah, buka langkah yang gagal dan kirim lognya.
