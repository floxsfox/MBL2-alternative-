cmake_minimum_required(VERSION 3.22)
project(mbloader LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# Versi SDK dipin supaya build bisa diulang. Ganti lewat -DPRELOADER_TAG=...
set(PRELOADER_TAG "0.2.2" CACHE STRING "Tag LiteLDev/preloader-android")

include(FetchContent)
FetchContent_Declare(
    preloader_android
    GIT_REPOSITORY https://github.com/LiteLDev/preloader-android.git
    GIT_TAG ${PRELOADER_TAG})
FetchContent_MakeAvailable(preloader_android)

add_library(mbloader SHARED
    src/main.cpp
    src/mod/MBloaderMod.cpp
    src/core/PackIndex.cpp)

target_include_directories(mbloader PRIVATE src)
# liblog: Logger.hpp (inline di SDK) memanggil __android_log_print
target_link_libraries(mbloader PRIVATE preloader log)
target_compile_options(mbloader PRIVATE -Wall -Wextra -Wno-unused-parameter)
set_target_properties(mbloader PROPERTIES OUTPUT_NAME mbloader) # -> libmbloader.so
