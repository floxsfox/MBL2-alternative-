#include "mod/MBloaderMod.h"

// Dipakai tepat sekali per library native.
PL_REGISTER_MOD(MBloaderMod, MBloaderMod::instance())
