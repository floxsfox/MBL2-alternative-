// MBloader - PackIndex
// Mencari file pengganti (material.bin) dari:
//   1) folder override milik mod:  <modDir>/override/<path asset>
//   2) resource pack GLOBAL yang sedang aktif (global_resource_packs.json)
// Tidak menyentuh internal game sama sekali, jadi tidak bergantung versi Minecraft.
#pragma once
#include <cstdint>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace mbl {

struct Config {
    bool enabled = true;
    bool verbose = false;               // log tiap file yang diganti
    bool useOverrideFolder = true;      // <mod>/override/...
    bool lastPackWins = true;           // pack paling bawah di daftar aktif = prioritas tertinggi
    bool headerMismatchSkip = false;    // false: tetap pakai + warning, true: pakai file bawaan game
    std::string gameDataDir;            // kosong = otomatis cari games/com.mojang
    int refreshMs = 1500;               // jeda minimum cek ulang daftar pack
    int maxFileMB = 64;                 // batas ukuran file pengganti

    static Config parse(const std::string &jsonText);
    static std::string defaultJson();
};

// Path asset yang boleh diganti. Hanya renderer/materials/*.material.bin.
bool isReplaceablePath(const std::string &assetPath);

bool readWholeFile(const std::string &path, std::vector<uint8_t> &out, size_t maxBytes);

class PackIndex {
public:
    PackIndex(std::string modDir, Config cfg);

    // Path file pengganti di disk, atau "" bila tidak ada.
    std::string find(const std::string &assetPath);

    std::string gameDir();          // games/com.mojang yang dipakai (bisa kosong)
    size_t activePackCount();       // jumlah pack aktif yang foldernya ketemu
    std::vector<std::string> activePackDirs();
    const Config &config() const { return mCfg; }

    // Dipakai test / diagnosa
    static std::vector<std::string> candidateGameDirs(const std::string &modDir, const std::string &override);

private:
    void refreshLocked(bool force);

    std::string mModDir;
    Config mCfg;
    std::mutex mMutex;
    int64_t mLastRefreshMs = -1000000;
    int64_t mStamp = -1;                         // mtime gabungan untuk deteksi perubahan
    std::string mGameDir;
    std::vector<std::string> mPackDirs;          // urut prioritas: index 0 = dicek pertama
    std::unordered_map<std::string, std::string> mCache; // asset -> file ("" = tidak ada)
};

int64_t nowMs();

} // namespace mbl
