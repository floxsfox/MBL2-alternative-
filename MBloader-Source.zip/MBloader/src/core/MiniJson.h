// MBloader - MiniJson: pembaca JSON sederhana (tanpa dependensi) untuk
// manifest.json, global_resource_packs.json dan config.json.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace mbl::json {

inline size_t skipWs(const std::string &s, size_t i) {
    while (i < s.size() && (s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n')) ++i;
    return i;
}

// Baca string JSON yang diawali tanda kutip pada posisi i.
inline bool readString(const std::string &s, size_t &i, std::string &out) {
    if (i >= s.size() || s[i] != '"') return false;
    ++i;
    out.clear();
    while (i < s.size()) {
        char c = s[i++];
        if (c == '"') return true;
        if (c == '\\' && i < s.size()) {
            char e = s[i++];
            switch (e) {
            case 'n': out += '\n'; break;
            case 't': out += '\t'; break;
            case 'r': out += '\r'; break;
            case 'u':
                if (i + 4 <= s.size()) i += 4;
                out += '?';
                break;
            default: out += e; break;
            }
        } else {
            out += c;
        }
    }
    return false;
}

// Semua nilai string untuk key tertentu, urut kemunculan (mis. "pack_id").
inline std::vector<std::string> findAllStrings(const std::string &s, const std::string &key) {
    std::vector<std::string> res;
    const std::string needle = "\"" + key + "\"";
    size_t pos = 0;
    while ((pos = s.find(needle, pos)) != std::string::npos) {
        size_t i = skipWs(s, pos + needle.size());
        pos += needle.size();
        if (i >= s.size() || s[i] != ':') continue;
        i = skipWs(s, i + 1);
        std::string v;
        if (readString(s, i, v)) {
            res.push_back(std::move(v));
            pos = i;
        }
    }
    return res;
}

// Nilai string pertama untuk key setelah posisi `from`.
inline bool findStringAfter(const std::string &s, size_t from, const std::string &key, std::string &out) {
    const std::string needle = "\"" + key + "\"";
    size_t pos = s.find(needle, from);
    while (pos != std::string::npos) {
        size_t i = skipWs(s, pos + needle.size());
        if (i < s.size() && s[i] == ':') {
            i = skipWs(s, i + 1);
            if (readString(s, i, out)) return true;
        }
        pos = s.find(needle, pos + needle.size());
    }
    return false;
}

// uuid header dari manifest.json pack (dicari setelah kata "header").
inline bool manifestUuid(const std::string &manifest, std::string &uuid) {
    size_t h = manifest.find("\"header\"");
    if (h == std::string::npos) return false;
    return findStringAfter(manifest, h, "uuid", uuid);
}

inline bool getBool(const std::string &s, const std::string &key, bool def) {
    const std::string needle = "\"" + key + "\"";
    size_t pos = s.find(needle);
    if (pos == std::string::npos) return def;
    size_t i = skipWs(s, pos + needle.size());
    if (i >= s.size() || s[i] != ':') return def;
    i = skipWs(s, i + 1);
    if (s.compare(i, 4, "true") == 0) return true;
    if (s.compare(i, 5, "false") == 0) return false;
    return def;
}

inline std::string getString(const std::string &s, const std::string &key, const std::string &def) {
    const std::string needle = "\"" + key + "\"";
    size_t pos = s.find(needle);
    if (pos == std::string::npos) return def;
    size_t i = skipWs(s, pos + needle.size());
    if (i >= s.size() || s[i] != ':') return def;
    i = skipWs(s, i + 1);
    std::string v;
    return readString(s, i, v) ? v : def;
}

inline int getInt(const std::string &s, const std::string &key, int def) {
    const std::string needle = "\"" + key + "\"";
    size_t pos = s.find(needle);
    if (pos == std::string::npos) return def;
    size_t i = skipWs(s, pos + needle.size());
    if (i >= s.size() || s[i] != ':') return def;
    i = skipWs(s, i + 1);
    bool neg = false;
    if (i < s.size() && s[i] == '-') { neg = true; ++i; }
    if (i >= s.size() || s[i] < '0' || s[i] > '9') return def;
    long v = 0;
    while (i < s.size() && s[i] >= '0' && s[i] <= '9' && v < 100000000) v = v * 10 + (s[i++] - '0');
    return static_cast<int>(neg ? -v : v);
}

} // namespace mbl::json
