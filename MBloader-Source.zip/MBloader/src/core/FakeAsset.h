// MBloader - FakeAsset
// Pengganti AAsset* untuk file yang kita ganti. Semua fungsi AAsset_* di-hook;
// pointer yang berasal dari sini dikenali lewat magic + self-pointer, sisanya
// diteruskan ke fungsi asli.
#pragma once
#include <cstdint>
#include <cstring>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace mbl {

struct FakeAsset {
    static constexpr uint64_t kMagic = 0x4D424C4F41444552ull; // "MBLOADER"
    uint64_t magic = kMagic; // HARUS field pertama
    FakeAsset *self = nullptr;
    std::string name;
    std::vector<uint8_t> data;
    int64_t pos = 0;
};

class FakeAssetStore {
public:
    FakeAsset *create(std::string name, std::vector<uint8_t> &&data) {
        auto fa = std::make_unique<FakeAsset>();
        fa->self = fa.get();
        fa->name = std::move(name);
        fa->data = std::move(data);
        FakeAsset *raw = fa.get();
        std::lock_guard<std::mutex> lock(mMutex);
        mAssets.emplace(raw, std::move(fa));
        return raw;
    }

    // Kembalikan FakeAsset bila `p` benar-benar milik kita, selain itu nullptr.
    // Cek pertama tanpa lock (baca 8 byte pertama; objek AAsset asli diawali vtable,
    // tidak pernah sama dengan kMagic).
    FakeAsset *lookup(const void *p) {
        if (!p) return nullptr;
        uint64_t m;
        std::memcpy(&m, p, sizeof(m));
        if (m != FakeAsset::kMagic) return nullptr;
        const FakeAsset *c = static_cast<const FakeAsset *>(p);
        if (c->self != c) return nullptr;
        std::lock_guard<std::mutex> lock(mMutex);
        auto it = mAssets.find(const_cast<FakeAsset *>(c));
        return it == mAssets.end() ? nullptr : it->second.get();
    }

    bool destroy(FakeAsset *fa) {
        std::lock_guard<std::mutex> lock(mMutex);
        auto it = mAssets.find(fa);
        if (it == mAssets.end()) return false;
        it->second->magic = 0;
        mAssets.erase(it);
        return true;
    }

    size_t outstanding() {
        std::lock_guard<std::mutex> lock(mMutex);
        return mAssets.size();
    }

    // ---- semantik AAsset_* ----
    static int64_t read(FakeAsset *a, void *buf, size_t count) {
        const int64_t size = static_cast<int64_t>(a->data.size());
        int64_t left = size - a->pos;
        if (left <= 0 || !buf) return 0;
        size_t n = count < static_cast<size_t>(left) ? count : static_cast<size_t>(left);
        std::memcpy(buf, a->data.data() + a->pos, n);
        a->pos += static_cast<int64_t>(n);
        return static_cast<int64_t>(n);
    }

    // whence: 0=SEEK_SET 1=SEEK_CUR 2=SEEK_END. Mengembalikan posisi baru atau -1.
    static int64_t seek(FakeAsset *a, int64_t offset, int whence) {
        const int64_t size = static_cast<int64_t>(a->data.size());
        int64_t target;
        switch (whence) {
        case 0: target = offset; break;
        case 1: target = a->pos + offset; break;
        case 2: target = size + offset; break;
        default: return -1;
        }
        if (target < 0 || target > size) return -1;
        a->pos = target;
        return target;
    }

    static int64_t length(const FakeAsset *a) { return static_cast<int64_t>(a->data.size()); }
    static int64_t remaining(const FakeAsset *a) { return static_cast<int64_t>(a->data.size()) - a->pos; }

private:
    std::mutex mMutex;
    std::unordered_map<FakeAsset *, std::unique_ptr<FakeAsset>> mAssets;
};

} // namespace mbl
