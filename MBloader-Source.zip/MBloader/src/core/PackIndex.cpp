#include "PackIndex.h"
#include "MiniJson.h"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <dirent.h>
#include <map>
#include <sys/stat.h>

namespace mbl {

int64_t nowMs() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

namespace {

bool statOf(const std::string &p, struct stat &st) { return ::stat(p.c_str(), &st) == 0; }

bool isDir(const std::string &p) {
    struct stat st;
    return statOf(p, st) && S_ISDIR(st.st_mode);
}

bool isFile(const std::string &p) {
    struct stat st;
    return statOf(p, st) && S_ISREG(st.st_mode) && st.st_size > 0;
}

// mtime dalam ms, -1 bila tidak ada.
int64_t mtimeOf(const std::string &p) {
    struct stat st;
    if (!statOf(p, st)) return -1;
    return static_cast<int64_t>(st.st_mtime) * 1000 + st.st_mtim.tv_nsec / 1000000;
}

std::string slurp(const std::string &path, size_t maxBytes = 4u << 20) {
    std::vector<uint8_t> buf;
    if (!readWholeFile(path, buf, maxBytes)) return {};
    return std::string(buf.begin(), buf.end());
}

std::vector<std::string> listDir(const std::string &path) {
    std::vector<std::string> out;
    DIR *d = ::opendir(path.c_str());
    if (!d) return out;
    while (dirent *e = ::readdir(d)) {
        if (!std::strcmp(e->d_name, ".") || !std::strcmp(e->d_name, "..")) continue;
        out.emplace_back(e->d_name);
    }
    ::closedir(d);
    std::sort(out.begin(), out.end());
    return out;
}

std::string lower(std::string s) {
    for (auto &c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

std::string trimSlash(std::string s) {
    while (s.size() > 1 && s.back() == '/') s.pop_back();
    return s;
}

std::string baseName(const std::string &p) {
    size_t i = p.rfind('/');
    return i == std::string::npos ? p : p.substr(i + 1);
}

// Cari */games/com.mojang di bawah `dir` (kedalaman & jumlah listing dibatasi).
void scanForMojang(const std::string &dir, int depth, int &budget, std::vector<std::string> &out) {
    if (budget <= 0 || depth > 4) return;
    --budget;
    for (const auto &name : listDir(dir)) {
        const std::string sub = dir + "/" + name;
        if (!isDir(sub)) continue;
        if (name == "com.mojang" && baseName(dir) == "games") {
            out.push_back(sub);
            continue;
        }
        if (name == "mods" || name == "lib" || name == "libs" || name == "cache" || name == "apk") continue;
        scanForMojang(sub, depth + 1, budget, out);
    }
}

} // namespace

// ---------------------------------------------------------------- Config

Config Config::parse(const std::string &t) {
    Config c;
    c.enabled = json::getBool(t, "enabled", c.enabled);
    c.verbose = json::getBool(t, "verbose", c.verbose);
    c.useOverrideFolder = json::getBool(t, "use_override_folder", c.useOverrideFolder);
    c.lastPackWins = json::getBool(t, "last_pack_wins", c.lastPackWins);
    c.headerMismatchSkip = json::getBool(t, "skip_on_header_mismatch", c.headerMismatchSkip);
    c.gameDataDir = json::getString(t, "game_data_dir", c.gameDataDir);
    c.refreshMs = std::max(0, std::min(60000, json::getInt(t, "refresh_ms", c.refreshMs)));
    c.maxFileMB = std::max(1, std::min(512, json::getInt(t, "max_file_mb", c.maxFileMB)));
    return c;
}

std::string Config::defaultJson() {
    return "{\n"
           "    \"version\": 1,\n"
           "    \"enabled\": true,\n"
           "    \"verbose\": false,\n"
           "    \"use_override_folder\": true,\n"
           "    \"last_pack_wins\": true,\n"
           "    \"skip_on_header_mismatch\": false,\n"
           "    \"game_data_dir\": \"\",\n"
           "    \"refresh_ms\": 1500,\n"
           "    \"max_file_mb\": 64\n"
           "}\n";
}

// ---------------------------------------------------------------- helpers

bool isReplaceablePath(const std::string &p) {
    static const std::string kPrefix = "renderer/materials/";
    static const std::string kSuffix = ".material.bin";
    if (p.size() <= kPrefix.size() + kSuffix.size() || p.size() > 200) return false;
    if (p.compare(0, kPrefix.size(), kPrefix) != 0) return false;
    if (p.compare(p.size() - kSuffix.size(), kSuffix.size(), kSuffix) != 0) return false;
    const std::string name = p.substr(kPrefix.size());
    if (name.find('/') != std::string::npos || name.find('\\') != std::string::npos) return false;
    if (name.find("..") != std::string::npos || name.find('\0') != std::string::npos) return false;
    return true;
}

bool readWholeFile(const std::string &path, std::vector<uint8_t> &out, size_t maxBytes) {
    out.clear();
    FILE *f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    if (std::fseek(f, 0, SEEK_END) != 0) { std::fclose(f); return false; }
    long size = std::ftell(f);
    if (size <= 0 || static_cast<size_t>(size) > maxBytes) { std::fclose(f); return false; }
    std::rewind(f);
    out.resize(static_cast<size_t>(size));
    size_t got = std::fread(out.data(), 1, out.size(), f);
    std::fclose(f);
    if (got != out.size()) { out.clear(); return false; }
    return true;
}

// ---------------------------------------------------------------- PackIndex

PackIndex::PackIndex(std::string modDir, Config cfg) : mModDir(trimSlash(std::move(modDir))), mCfg(std::move(cfg)) {}

std::vector<std::string> PackIndex::candidateGameDirs(const std::string &modDir, const std::string &overrideDir) {
    std::vector<std::string> c;
    auto add = [&](std::string p) {
        p = trimSlash(std::move(p));
        if (!p.empty() && std::find(c.begin(), c.end(), p) == c.end()) c.push_back(std::move(p));
    };

    if (!overrideDir.empty()) {
        add(overrideDir);
        add(overrideDir + "/games/com.mojang");
        add(overrideDir + "/com.mojang");
    }

    // Folder induk dari mod: <profil>/mods/<id> -> <profil>/games/com.mojang
    std::string cur = trimSlash(modDir);
    for (int i = 0; i < 7; ++i) {
        size_t slash = cur.rfind('/');
        if (slash == std::string::npos || slash == 0) break;
        cur = cur.substr(0, slash);
        add(cur + "/games/com.mojang");
    }

    for (const char *root : {"/storage/emulated/0", "/sdcard"}) {
        const std::string r = root;
        add(r + "/Android/data/org.levimc.launcher/files/games/com.mojang");
        add(r + "/Android/media/org.levimc.launcher/games/com.mojang");
        add(r + "/Android/data/com.mojang.minecraftpe/files/games/com.mojang");
        add(r + "/games/com.mojang");
        int budget = 300;
        std::vector<std::string> found;
        scanForMojang(r + "/Android/media/org.levimc.launcher", 0, budget, found);
        scanForMojang(r + "/Android/data/org.levimc.launcher", 0, budget, found);
        for (auto &f : found) add(f);
    }
    return c;
}

void PackIndex::refreshLocked(bool force) {
    const int64_t now = nowMs();
    if (!force && now - mLastRefreshMs < mCfg.refreshMs) return;
    mLastRefreshMs = now;
    mCache.clear(); // hasil pencarian hanya valid selama jendela refresh

    // 1) pilih game dir: yang paling baru dipakai
    std::string best;
    int64_t bestStamp = -1;
    for (const auto &c : candidateGameDirs(mModDir, mCfg.gameDataDir)) {
        if (!isDir(c)) continue;
        int64_t st = std::max(mtimeOf(c + "/minecraftpe/global_resource_packs.json"), mtimeOf(c + "/minecraftpe/options.txt"));
        if (st < 0) {
            if (!isDir(c + "/resource_packs")) continue;
            st = 0;
        }
        if (st > bestStamp) {
            bestStamp = st;
            best = c;
        }
    }

    const int64_t stamp = best.empty() ? -2
        : mtimeOf(best + "/minecraftpe/global_resource_packs.json") * 31 + mtimeOf(best + "/resource_packs") * 17 +
              mtimeOf(best + "/development_resource_packs");
    if (best == mGameDir && stamp == mStamp && !force) return; // tidak ada perubahan
    mGameDir = best;
    mStamp = stamp;
    mPackDirs.clear();
    if (best.empty()) return;

    // 2) uuid -> folder pack
    std::map<std::string, std::string> uuidToDir;
    for (const char *base : {"resource_packs", "development_resource_packs"}) {
        const std::string baseDir = best + "/" + base;
        for (const auto &name : listDir(baseDir)) {
            std::string dir = baseDir + "/" + name;
            if (!isDir(dir)) continue;
            std::string manifest = slurp(dir + "/manifest.json", 1u << 20);
            if (manifest.empty()) { // beberapa pack dibungkus 1 folder lagi
                for (const auto &inner : listDir(dir)) {
                    std::string d2 = dir + "/" + inner;
                    if (!isDir(d2)) continue;
                    manifest = slurp(d2 + "/manifest.json", 1u << 20);
                    if (!manifest.empty()) { dir = d2; break; }
                }
            }
            std::string uuid;
            if (manifest.empty() || !json::manifestUuid(manifest, uuid)) continue;
            uuid = lower(uuid);
            // development_resource_packs menimpa resource_packs bila uuid sama
            if (!uuidToDir.count(uuid) || std::string(base) == "development_resource_packs") uuidToDir[uuid] = dir;
        }
    }

    // 3) daftar aktif (urutan file) -> folder
    const std::string active = slurp(best + "/minecraftpe/global_resource_packs.json");
    std::vector<std::string> dirs;
    for (auto id : json::findAllStrings(active, "pack_id")) {
        auto it = uuidToDir.find(lower(id));
        if (it != uuidToDir.end() && std::find(dirs.begin(), dirs.end(), it->second) == dirs.end()) dirs.push_back(it->second);
    }
    if (mCfg.lastPackWins) std::reverse(dirs.begin(), dirs.end());
    mPackDirs = std::move(dirs);
}

std::string PackIndex::find(const std::string &assetPath) {
    if (!isReplaceablePath(assetPath)) return {};
    std::lock_guard<std::mutex> lock(mMutex);
    refreshLocked(false);

    auto it = mCache.find(assetPath);
    if (it != mCache.end()) return it->second;

    std::string result;
    if (mCfg.useOverrideFolder) {
        const std::string p = mModDir + "/override/" + assetPath;
        if (isFile(p)) result = p;
    }
    if (result.empty()) {
        for (const auto &dir : mPackDirs) {
            const std::string p = dir + "/" + assetPath;
            if (isFile(p)) { result = p; break; }
        }
    }
    mCache[assetPath] = result;
    return result;
}

std::string PackIndex::gameDir() {
    std::lock_guard<std::mutex> lock(mMutex);
    refreshLocked(false);
    return mGameDir;
}

size_t PackIndex::activePackCount() {
    std::lock_guard<std::mutex> lock(mMutex);
    refreshLocked(false);
    return mPackDirs.size();
}

std::vector<std::string> PackIndex::activePackDirs() {
    std::lock_guard<std::mutex> lock(mMutex);
    refreshLocked(false);
    return mPackDirs;
}

} // namespace mbl
