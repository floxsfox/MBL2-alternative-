#include "MBloaderMod.h"

#include "../core/FakeAsset.h"
#include "../core/PackIndex.h"

#include <android/asset_manager.h>
#include <pl/Logger.hpp>
#include <pl/memory/Hook.hpp>

#include <atomic>
#include <cstring>
#include <dlfcn.h>
#include <filesystem>
#include <fstream>
#include <memory>
#include <sstream>
#include <string>
#include <sys/types.h>

namespace {

// ------------------------------------------------------------------ state

struct Originals {
    AAsset *(*open)(AAssetManager *, const char *, int) = nullptr;
    int (*read)(AAsset *, void *, size_t) = nullptr;
    off_t (*seek)(AAsset *, off_t, int) = nullptr;
    off64_t (*seek64)(AAsset *, off64_t, int) = nullptr;
    void (*close)(AAsset *) = nullptr;
    const void *(*getBuffer)(AAsset *) = nullptr;
    off_t (*getLength)(AAsset *) = nullptr;
    off64_t (*getLength64)(AAsset *) = nullptr;
    off_t (*getRemaining)(AAsset *) = nullptr;
    off64_t (*getRemaining64)(AAsset *) = nullptr;
    int (*openFd)(AAsset *, off_t *, off_t *) = nullptr;
    int (*openFd64)(AAsset *, off64_t *, off64_t *) = nullptr;
    int (*isAllocated)(AAsset *) = nullptr;
};

constexpr int kHookCount = 13;

struct Runtime {
    ll::mod::NativeMod *self = nullptr;
    std::unique_ptr<mbl::PackIndex> index;
    mbl::Config cfg;
    pl::memory::HookHandle hooks[kHookCount];
    std::atomic<long> replaced{0};
    std::atomic<bool> loggedFirst{false};
};

Originals gOrig;
mbl::FakeAssetStore gStore;
std::atomic<bool> gActive{false};
Runtime *gRt = nullptr; // sengaja tidak pernah di-delete (hidup selama proses)

// ------------------------------------------------------------------ log

void logInfo(const std::string &m) {
    if (gRt && gRt->self) gRt->self->getLogger().info("{}", m);
}
void logWarn(const std::string &m) {
    if (gRt && gRt->self) gRt->self->getLogger().warn("{}", m);
}
void logError(const std::string &m) {
    if (gRt && gRt->self) gRt->self->getLogger().error("{}", m);
}

std::string pathStr(const std::filesystem::path &p) { return p.string(); }

// ------------------------------------------------------------------ detour

AAsset *hkOpen(AAssetManager *mgr, const char *filename, int mode) {
    Runtime *rt = gRt;
    if (!rt || !gActive.load(std::memory_order_relaxed) || !filename || !rt->index) {
        return gOrig.open(mgr, filename, mode);
    }

    const std::string name(filename);
    if (!mbl::isReplaceablePath(name)) return gOrig.open(mgr, filename, mode);

    // Log diagnosa sekali, saat material pertama diminta game.
    if (!rt->loggedFirst.exchange(true)) {
        const std::string dir = rt->index->gameDir();
        if (dir.empty()) {
            logWarn("games/com.mojang tidak ketemu. Isi \"game_data_dir\" di config/config.json bila shader tidak termuat.");
        } else {
            logInfo("games/com.mojang: " + dir);
            logInfo("resource pack aktif yang ditemukan: " + std::to_string(rt->index->activePackCount()));
        }
    }

    const std::string file = rt->index->find(name);
    if (file.empty()) return gOrig.open(mgr, filename, mode);

    std::vector<uint8_t> data;
    if (!mbl::readWholeFile(file, data, static_cast<size_t>(rt->cfg.maxFileMB) << 20) || data.size() < 8) {
        logWarn("gagal membaca " + file + " (kosong / terlalu besar), pakai file bawaan game");
        return gOrig.open(mgr, filename, mode);
    }

    // Cek ringan: 8 byte pertama (magic) dibanding file asli di APK.
    if (gOrig.read && gOrig.close) {
        if (AAsset *probe = gOrig.open(mgr, filename, mode)) {
            uint8_t hdr[8] = {0};
            const int n = gOrig.read(probe, hdr, 8);
            gOrig.close(probe);
            if (n == 8 && std::memcmp(hdr, data.data(), 8) != 0) {
                logWarn("header " + name + " beda dengan bawaan game (shader untuk versi lain?)");
                if (rt->cfg.headerMismatchSkip) return gOrig.open(mgr, filename, mode);
            }
        }
    }

    const size_t size = data.size();
    mbl::FakeAsset *fa = gStore.create(name, std::move(data));
    const long count = rt->replaced.fetch_add(1) + 1;
    if (rt->cfg.verbose || count <= 3 || count % 25 == 0) {
        logInfo("[" + std::to_string(count) + "] " + name + " <- " + file + " (" + std::to_string(size) + " B)");
    }
    return reinterpret_cast<AAsset *>(fa);
}

int hkRead(AAsset *a, void *buf, size_t n) {
    if (auto *f = gStore.lookup(a)) return static_cast<int>(mbl::FakeAssetStore::read(f, buf, n));
    return gOrig.read(a, buf, n);
}

off_t hkSeek(AAsset *a, off_t off, int whence) {
    if (auto *f = gStore.lookup(a)) return static_cast<off_t>(mbl::FakeAssetStore::seek(f, off, whence));
    return gOrig.seek(a, off, whence);
}

off64_t hkSeek64(AAsset *a, off64_t off, int whence) {
    if (auto *f = gStore.lookup(a)) return static_cast<off64_t>(mbl::FakeAssetStore::seek(f, off, whence));
    return gOrig.seek64(a, off, whence);
}

void hkClose(AAsset *a) {
    if (auto *f = gStore.lookup(a)) {
        gStore.destroy(f);
        return;
    }
    gOrig.close(a);
}

const void *hkGetBuffer(AAsset *a) {
    if (auto *f = gStore.lookup(a)) return f->data.data();
    return gOrig.getBuffer(a);
}

off_t hkGetLength(AAsset *a) {
    if (auto *f = gStore.lookup(a)) return static_cast<off_t>(mbl::FakeAssetStore::length(f));
    return gOrig.getLength(a);
}

off64_t hkGetLength64(AAsset *a) {
    if (auto *f = gStore.lookup(a)) return static_cast<off64_t>(mbl::FakeAssetStore::length(f));
    return gOrig.getLength64(a);
}

off_t hkGetRemaining(AAsset *a) {
    if (auto *f = gStore.lookup(a)) return static_cast<off_t>(mbl::FakeAssetStore::remaining(f));
    return gOrig.getRemaining(a);
}

off64_t hkGetRemaining64(AAsset *a) {
    if (auto *f = gStore.lookup(a)) return static_cast<off64_t>(mbl::FakeAssetStore::remaining(f));
    return gOrig.getRemaining64(a);
}

int hkOpenFd(AAsset *a, off_t *start, off_t *length) {
    if (gStore.lookup(a)) return -1; // data ada di memori, tidak ada fd
    return gOrig.openFd(a, start, length);
}

int hkOpenFd64(AAsset *a, off64_t *start, off64_t *length) {
    if (gStore.lookup(a)) return -1;
    return gOrig.openFd64(a, start, length);
}

int hkIsAllocated(AAsset *a) {
    if (gStore.lookup(a)) return 1;
    return gOrig.isAllocated(a);
}

// ------------------------------------------------------------------ install

void *resolveSymbol(const char *sym) {
    static void *lib = ::dlopen("libandroid.so", RTLD_NOW);
    void *p = lib ? ::dlsym(lib, sym) : nullptr;
    if (!p) p = ::dlsym(RTLD_DEFAULT, sym);
    return p;
}

// true = aman dilanjutkan (terpasang, atau simbol memang tidak ada di perangkat ini).
// false = simbol ada tetapi hook gagal dipasang -> seluruh pemasangan dibatalkan.
template <typename Fn>
bool installOne(const char *sym, Fn detour, Fn *orig, pl::memory::HookHandle &handle) {
    void *target = resolveSymbol(sym);
    if (!target) {
        logWarn(std::string("simbol tidak ada, dilewati: ") + sym);
        return true;
    }
    handle = pl::memory::HookHandle(target, reinterpret_cast<void *>(detour), reinterpret_cast<void **>(orig),
                                    pl::memory::HookPriority::Normal);
    if (!handle.installed()) {
        logError(std::string("gagal memasang hook: ") + sym);
        return false;
    }
    return true;
}

bool installAll(Runtime &rt) {
    int i = 0;
    // Fungsi turunan AAsset dipasang dulu (belum berefek karena belum ada FakeAsset),
    // AAssetManager_open dipasang paling akhir sehingga FakeAsset tidak pernah
    // bocor ke fungsi asli.
    bool ok = installOne("AAsset_close", hkClose, &gOrig.close, rt.hooks[i++]) &&
              installOne("AAsset_read", hkRead, &gOrig.read, rt.hooks[i++]) &&
              installOne("AAsset_seek", hkSeek, &gOrig.seek, rt.hooks[i++]) &&
              installOne("AAsset_seek64", hkSeek64, &gOrig.seek64, rt.hooks[i++]) &&
              installOne("AAsset_getBuffer", hkGetBuffer, &gOrig.getBuffer, rt.hooks[i++]) &&
              installOne("AAsset_getLength", hkGetLength, &gOrig.getLength, rt.hooks[i++]) &&
              installOne("AAsset_getLength64", hkGetLength64, &gOrig.getLength64, rt.hooks[i++]) &&
              installOne("AAsset_getRemainingLength", hkGetRemaining, &gOrig.getRemaining, rt.hooks[i++]) &&
              installOne("AAsset_getRemainingLength64", hkGetRemaining64, &gOrig.getRemaining64, rt.hooks[i++]) &&
              installOne("AAsset_openFileDescriptor", hkOpenFd, &gOrig.openFd, rt.hooks[i++]) &&
              installOne("AAsset_openFileDescriptor64", hkOpenFd64, &gOrig.openFd64, rt.hooks[i++]) &&
              installOne("AAsset_isAllocated", hkIsAllocated, &gOrig.isAllocated, rt.hooks[i++]) &&
              installOne("AAssetManager_open", hkOpen, &gOrig.open, rt.hooks[i++]);
    if (!ok) {
        for (auto &h : rt.hooks) h.reset();
        return false;
    }
    if (!gOrig.open) {
        logError("AAssetManager_open tidak ditemukan di perangkat ini");
        for (auto &h : rt.hooks) h.reset();
        return false;
    }
    return true;
}

} // namespace

// ------------------------------------------------------------------ lifecycle

MBloaderMod &MBloaderMod::instance() {
    static MBloaderMod inst;
    return inst;
}

MBloaderMod::MBloaderMod() : mSelf(*ll::mod::NativeMod::current()) {}

bool MBloaderMod::load() {
    try {
        auto &self = getSelf();
        const std::filesystem::path cfgDir(self.getConfigDir());
        const std::filesystem::path modDir(self.getModDir());
        std::filesystem::create_directories(cfgDir);
        std::filesystem::create_directories(modDir / "override" / "renderer" / "materials");

        const std::filesystem::path cfgPath = cfgDir / "config.json";
        std::string text;
        {
            std::ifstream in(cfgPath);
            if (in) {
                std::ostringstream ss;
                ss << in.rdbuf();
                text = ss.str();
            }
        }
        if (text.empty()) {
            text = mbl::Config::defaultJson();
            std::ofstream out(cfgPath, std::ios::trunc);
            out << text;
        }

        if (!gRt) gRt = new Runtime();
        gRt->self = &self;
        gRt->cfg = mbl::Config::parse(text);
        gRt->index = std::make_unique<mbl::PackIndex>(pathStr(modDir), gRt->cfg);
        logInfo("dimuat (versi " + std::string(self.getVersion()) + ")");
        return true;
    } catch (const std::exception &e) {
        if (gRt) logError(std::string("load() gagal: ") + e.what());
        return false;
    } catch (...) {
        return false;
    }
}

bool MBloaderMod::enable() {
    try {
        if (!gRt || !gRt->index) return false;
        if (!gRt->cfg.enabled) {
            logInfo("dimatikan lewat config (enabled=false)");
            return true;
        }
        if (!installAll(*gRt)) {
            logError("hook asset gagal dipasang; MBloader tidak aktif");
            return false;
        }
        gActive.store(true);
        logInfo("aktif: material.bin akan dimuat dari resource pack global yang aktif");
        return true;
    } catch (const std::exception &e) {
        logError(std::string("enable() gagal: ") + e.what());
        return false;
    } catch (...) {
        return false;
    }
}

bool MBloaderMod::disable() {
    // Hook dibiarkan terpasang supaya FakeAsset yang masih terbuka tetap aman;
    // yang dimatikan hanya pengalihan file baru.
    gActive.store(false);
    if (gRt) logInfo("dinonaktifkan");
    return true;
}

bool MBloaderMod::unload() {
    gActive.store(false);
    if (gRt && gStore.outstanding() == 0) {
        for (auto &h : gRt->hooks) h.reset();
    }
    return true;
}
