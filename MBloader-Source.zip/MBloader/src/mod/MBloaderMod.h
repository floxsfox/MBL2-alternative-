#pragma once

#include <pl/Mod.hpp>

// Mod native LeviLauncher (Android, arm64-v8a).
// Siklus hidup: load() -> enable() -> disable() -> unload()
class MBloaderMod {
public:
    static MBloaderMod &instance();

    MBloaderMod();

    [[nodiscard]] ll::mod::NativeMod &getSelf() const { return mSelf; }

    bool load();
    bool enable();
    bool disable();
    bool unload();

private:
    ll::mod::NativeMod &mSelf;
};
