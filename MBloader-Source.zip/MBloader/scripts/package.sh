#!/usr/bin/env bash
# Build libmbloader.so (arm64-v8a) dan bungkus jadi mbloader.levipack
# Butuh: ANDROID_NDK_HOME (NDK r28c / 28.2.13676358), cmake >= 3.22, ninja, zip
set -euo pipefail
cd "$(dirname "$0")/.."

: "${ANDROID_NDK_HOME:?Set ANDROID_NDK_HOME ke folder NDK}"
ID=mbloader
BUILD=build-arm64-v8a
DIST=dist/arm64-v8a

cmake -S . -B "$BUILD" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-28 \
  -DANDROID_STL=c++_shared
cmake --build "$BUILD" --target mbloader

SO="$BUILD/libmbloader.so"
test -f "$SO" || { echo "libmbloader.so tidak terbentuk"; exit 1; }

STRIP="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
[ -x "$STRIP" ] && "$STRIP" --strip-unneeded "$SO" || true

rm -rf "$DIST"
mkdir -p "$DIST/$ID/config"
cp manifest.json "$DIST/$ID/manifest.json"
cp "$SO" "$DIST/$ID/libmbloader.so"
cp config/config.json "$DIST/$ID/config/config.json"
( cd "$DIST" && zip -qr "$ID.levipack" "$ID" )

echo "Selesai: $DIST/$ID.levipack"
