# MBloader

Plug-in native untuk **LeviLauncher (Android, arm64-v8a)** yang membuat Minecraft Bedrock
memuat shader RenderDragon (`.material.bin`) langsung dari **resource pack**. Pengganti
MaterialBinLoader 2 yang tidak bergantung pada versi Minecraft.

## Kenapa lebih stabil
MBL2 mencari `ResourcePackManager` lewat byte-signature konstruktor, jadi patah setiap kali
Mojang mengubah kode (contoh: 1.26.60 membuang 1 argumen konstruktor). MBloader **tidak
menyentuh internal game**. Ia hanya meng-hook fungsi NDK `AAssetManager_open` / `AAsset_*`
(API Android yang stabil), lalu membaca file pengganti langsung dari folder resource pack
aktif. Tidak ada signature, tidak ada offset, tidak ada vtable.

## Pasang
1. Build lewat GitHub Actions (lihat `GITHUB_SETUP.md`) dan download `mbloader.levipack`.
2. LeviLauncher > Mods > Add Mod > pilih `mbloader.levipack`.
3. **Matikan MBL2 / mtbinloader2-levi** bila terpasang (keduanya meng-hook fungsi yang sama).
4. Import shader `.mcpack` ke Minecraft, aktifkan di **Global Resources**, lalu jalankan game dari Levi.

## Cara kerja pencarian file
Urutan prioritas untuk `renderer/materials/<nama>.material.bin`:
1. `<folder mod>/override/renderer/materials/<nama>.material.bin` (taruh manual di sini, opsional)
2. Resource pack global yang aktif (`minecraftpe/global_resource_packs.json`)
3. File bawaan game (kalau tidak ada pengganti)

Folder `games/com.mojang` dicari otomatis (folder induk mod, lalu lokasi umum Levi dan
Minecraft). Daftar pack dicek ulang otomatis saat kamu ganti pack, tanpa restart.

## Config (`config/config.json` di folder mod)
| Key | Default | Fungsi |
|---|---|---|
| `enabled` | `true` | Matikan plug-in tanpa menghapusnya |
| `verbose` | `false` | Log setiap file yang diganti |
| `use_override_folder` | `true` | Pakai folder `override/` |
| `last_pack_wins` | `true` | Pack paling bawah di daftar aktif menang bila ada file kembar |
| `skip_on_header_mismatch` | `false` | `true` = pakai file bawaan game bila 8 byte header file pack beda |
| `game_data_dir` | `""` | Isi manual bila `games/com.mojang` tidak ketemu otomatis |
| `refresh_ms` | `1500` | Jeda minimum cek ulang daftar pack |
| `max_file_mb` | `64` | Batas ukuran file pengganti |

## Batasan (jujur)
- **Belum ada autofix.** MBL2 bisa memperbarui shader lama ke format versi game. MBloader memuat
  file apa adanya, jadi shader harus dibuat untuk versi Minecraft yang kamu pakai. Shader lama
  bisa diperbarui dulu dengan tool `material-updater` (mcbegamerxx954).
- Hanya `renderer/materials/*.material.bin` dari **resource pack global**. Pack khusus dunia
  atau pack dari server belum dibaca.
- Pack terenkripsi (marketplace) tidak didukung.
- **Belum diuji di perangkat asli.** Logika inti dan hook sudah diuji di PC memakai stub SDK;
  uji di game nyata ada di langkah kamu. Kirim log bila ada masalah.

## Cek log
Tag log: `MBloader`. Baris yang harus muncul saat game mulai:
```
aktif: material.bin akan dimuat dari resource pack global yang aktif
games/com.mojang: /storage/emulated/0/...
resource pack aktif yang ditemukan: 1
[1] renderer/materials/RenderChunk.material.bin <- .../resource_packs/... (… B)
```
Kalau `resource pack aktif` bernilai 0: shader belum aktif di Global Resources, atau
`game_data_dir` perlu diisi manual.

## Struktur
```
CMakeLists.txt, manifest.json, config/config.json
src/main.cpp                 PL_REGISTER_MOD
src/mod/MBloaderMod.*        siklus hidup + hook AAsset_*
src/core/PackIndex.*         cari game dir, pack aktif, file pengganti
src/core/FakeAsset.h         AAsset palsu berisi data pengganti
src/core/MiniJson.h          pembaca JSON ringan
tests/                       uji host (logika + integrasi hook dengan stub)
scripts/package.sh           build + bungkus .levipack
```
Dibangun di atas SDK `LiteLDev/preloader-android` (dipin ke tag 0.2.2, ubah lewat `-DPRELOADER_TAG=`).
