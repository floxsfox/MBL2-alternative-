// Uji logika inti di PC/host (tanpa Android & tanpa SDK):
//   g++ -std=c++20 -I src tests/host_test.cpp src/core/PackIndex.cpp -o host_test && ./host_test
#include "core/FakeAsset.h"
#include "core/MiniJson.h"
#include "core/PackIndex.h"

#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>

namespace fs = std::filesystem;
static int gFail = 0;
#define CHECK(c)                                                                         \
    do {                                                                                 \
        if (!(c)) {                                                                      \
            std::printf("GAGAL  %s:%d  %s\n", __FILE__, __LINE__, #c);                   \
            ++gFail;                                                                     \
        }                                                                                \
    } while (0)

static void put(const fs::path &p, const std::string &s) {
    fs::create_directories(p.parent_path());
    std::ofstream o(p, std::ios::binary);
    o << s;
}

static void makePack(const fs::path &games, const std::string &folder, const std::string &uuid, const std::string &payload,
                     bool withModulesFirst = false) {
    std::string m;
    if (withModulesFirst) {
        m = "{\"modules\":[{\"type\":\"resources\",\"uuid\":\"11111111-aaaa-bbbb-cccc-000000000000\",\"version\":[1,0,0]}],"
            "\"format_version\":2,\"header\":{\"name\":\"x\",\"uuid\":\"" + uuid + "\",\"version\":[1,0,0]}}";
    } else {
        m = "{\"format_version\":2,\"header\":{\"name\":\"x\",\"uuid\":\"" + uuid +
            "\",\"version\":[1,0,0]},\"modules\":[{\"type\":\"resources\",\"uuid\":\"22222222-aaaa-bbbb-cccc-000000000000\"}]}";
    }
    put(games / "resource_packs" / folder / "manifest.json", "\xEF\xBB\xBF" + m); // dengan BOM
    put(games / "resource_packs" / folder / "renderer/materials/RenderChunk.material.bin", payload + "-RenderChunk");
    put(games / "resource_packs" / folder / "renderer/materials/Sky.material.bin", payload + "-Sky");
}

int main() {
    // ---- isReplaceablePath
    CHECK(mbl::isReplaceablePath("renderer/materials/RenderChunk.material.bin"));
    CHECK(!mbl::isReplaceablePath("renderer/materials/../x.material.bin"));
    CHECK(!mbl::isReplaceablePath("renderer/materials/sub/Foo.material.bin"));
    CHECK(!mbl::isReplaceablePath("renderer/materials/Foo.json"));
    CHECK(!mbl::isReplaceablePath("/renderer/materials/Foo.material.bin"));
    CHECK(!mbl::isReplaceablePath("textures/terrain.png"));
    CHECK(!mbl::isReplaceablePath(""));

    // ---- MiniJson
    std::string uuid;
    CHECK(mbl::json::manifestUuid("{\"modules\":[{\"uuid\":\"M\"}],\"header\":{\"uuid\":\"H-1\"}}", uuid) && uuid == "H-1");
    auto ids = mbl::json::findAllStrings("[{\"pack_id\":\"a\",\"version\":[1]},{ \"pack_id\" : \"b\" }]", "pack_id");
    CHECK(ids.size() == 2 && ids[0] == "a" && ids[1] == "b");
    CHECK(mbl::json::getBool("{\"x\": true}", "x", false));
    CHECK(!mbl::json::getBool("{\"x\": false}", "x", true));
    CHECK(mbl::json::getInt("{\"n\": -42}", "n", 0) == -42);
    CHECK(mbl::json::getString("{\"s\": \"a\\\\b\"}", "s", "") == "a\\b");

    // ---- Config
    mbl::Config d = mbl::Config::parse(mbl::Config::defaultJson());
    CHECK(d.enabled && !d.verbose && d.useOverrideFolder && d.lastPackWins && !d.headerMismatchSkip && d.refreshMs == 1500);
    mbl::Config c2 = mbl::Config::parse("{\"enabled\":false,\"refresh_ms\":999999,\"max_file_mb\":0,\"game_data_dir\":\"/x\"}");
    CHECK(!c2.enabled && c2.refreshMs == 60000 && c2.maxFileMB == 1 && c2.gameDataDir == "/x");

    // ---- PackIndex
    const fs::path root = fs::temp_directory_path() / "mbl_host_test";
    fs::remove_all(root);
    const fs::path prof = root / "Android/media/org.levimc.launcher/minecraft/prof";
    const fs::path games = prof / "games/com.mojang";
    const fs::path modDir = prof / "mods/mbloader";
    fs::create_directories(modDir);

    makePack(games, "ShaderA", "AAAAAAAA-0000-0000-0000-000000000001", "A");
    makePack(games, "ShaderB", "bbbbbbbb-0000-0000-0000-000000000002", "B", /*withModulesFirst=*/true);
    makePack(games, "Unused", "cccccccc-0000-0000-0000-000000000003", "U");
    put(games / "minecraftpe/global_resource_packs.json",
        "[{\"pack_id\":\"aaaaaaaa-0000-0000-0000-000000000001\",\"version\":[1,0,0]},"
        "{\"pack_id\":\"BBBBBBBB-0000-0000-0000-000000000002\",\"version\":[1,0,0]}]");

    mbl::Config cfg;
    cfg.refreshMs = 0;
    cfg.gameDataDir = games.string(); // deterministik; jalur ancestor diuji terpisah di bawah
    {
        mbl::PackIndex idx(modDir.string(), cfg);
        CHECK(idx.gameDir() == games.string());
        CHECK(idx.activePackCount() == 2);
        // last_pack_wins: B (paling bawah di daftar) menang
        std::string r = idx.find("renderer/materials/RenderChunk.material.bin");
        CHECK(r == (games / "resource_packs/ShaderB/renderer/materials/RenderChunk.material.bin").string());
        // pack tidak aktif tidak dipakai
        CHECK(idx.find("renderer/materials/Nope.material.bin").empty());
        // path ilegal ditolak
        CHECK(idx.find("renderer/materials/../../x.material.bin").empty());
        CHECK(idx.find("assets/other.bin").empty());
    }
    {
        cfg.lastPackWins = false;
        mbl::PackIndex idx(modDir.string(), cfg);
        std::string r = idx.find("renderer/materials/Sky.material.bin");
        CHECK(r == (games / "resource_packs/ShaderA/renderer/materials/Sky.material.bin").string());
        cfg.lastPackWins = true;
    }
    {
        // override folder menang atas pack
        put(modDir / "override/renderer/materials/Sky.material.bin", "OVERRIDE");
        mbl::PackIndex idx(modDir.string(), cfg);
        std::string r = idx.find("renderer/materials/Sky.material.bin");
        CHECK(r == (modDir / "override/renderer/materials/Sky.material.bin").string());
        std::vector<uint8_t> data;
        CHECK(mbl::readWholeFile(r, data, 1 << 20) && std::string(data.begin(), data.end()) == "OVERRIDE");
        CHECK(!mbl::readWholeFile(r, data, 3)); // melebihi batas
        mbl::Config off = cfg;
        off.useOverrideFolder = false;
        mbl::PackIndex idx2(modDir.string(), off);
        CHECK(idx2.find("renderer/materials/Sky.material.bin") !=
              (modDir / "override/renderer/materials/Sky.material.bin").string());
    }
    {
        // perubahan daftar pack terdeteksi tanpa restart
        mbl::PackIndex idx(modDir.string(), cfg);
        CHECK(idx.activePackCount() == 2);
        put(games / "minecraftpe/global_resource_packs.json",
            "[{\"pack_id\":\"cccccccc-0000-0000-0000-000000000003\",\"version\":[1,0,0]}]");
        CHECK(idx.activePackCount() == 1);
        CHECK(idx.find("renderer/materials/RenderChunk.material.bin") ==
              (games / "resource_packs/Unused/renderer/materials/RenderChunk.material.bin").string());
        put(games / "minecraftpe/global_resource_packs.json", "[]");
        CHECK(idx.activePackCount() == 0);
        CHECK(idx.find("renderer/materials/RenderChunk.material.bin") !=
              (games / "resource_packs/Unused/renderer/materials/RenderChunk.material.bin").string());
    }
    {
        // penemuan otomatis lewat folder induk mod (tanpa game_data_dir)
        put(games / "minecraftpe/global_resource_packs.json",
            "[{\"pack_id\":\"aaaaaaaa-0000-0000-0000-000000000001\",\"version\":[1,0,0]}]");
        mbl::Config auto_cfg;
        auto_cfg.refreshMs = 0;
        auto_cfg.useOverrideFolder = false;
        mbl::PackIndex idx(modDir.string(), auto_cfg);
        CHECK(idx.gameDir() == games.string());
        CHECK(idx.find("renderer/materials/Sky.material.bin") ==
              (games / "resource_packs/ShaderA/renderer/materials/Sky.material.bin").string());
    }

    // ---- FakeAssetStore
    {
        mbl::FakeAssetStore st;
        std::vector<uint8_t> bytes = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        auto *a = st.create("x", std::move(bytes));
        CHECK(st.lookup(a) == a);
        CHECK(st.outstanding() == 1);
        uint8_t buf[16] = {0};
        CHECK(mbl::FakeAssetStore::read(a, buf, 4) == 4 && buf[0] == 1 && buf[3] == 4);
        CHECK(mbl::FakeAssetStore::remaining(a) == 6);
        CHECK(mbl::FakeAssetStore::seek(a, -2, 2) == 8);
        CHECK(mbl::FakeAssetStore::read(a, buf, 16) == 2 && buf[0] == 9);
        CHECK(mbl::FakeAssetStore::read(a, buf, 16) == 0);
        CHECK(mbl::FakeAssetStore::seek(a, 100, 0) == -1);
        CHECK(mbl::FakeAssetStore::seek(a, 0, 7) == -1);
        CHECK(mbl::FakeAssetStore::seek(a, 3, 0) == 3 && mbl::FakeAssetStore::seek(a, 2, 1) == 5);
        CHECK(mbl::FakeAssetStore::length(a) == 10);

        // pointer asli (diawali "vtable") tidak boleh dikenali
        struct RealLike { void *vtable; int x; } real{reinterpret_cast<void *>(0x1234), 7};
        CHECK(st.lookup(&real) == nullptr);
        CHECK(st.lookup(nullptr) == nullptr);

        CHECK(st.destroy(a));
        CHECK(st.outstanding() == 0);
    }

    if (gFail == 0) std::printf("SEMUA UJI LULUS\n");
    else std::printf("%d uji gagal\n", gFail);
    fs::remove_all(root);
    return gFail == 0 ? 0 : 1;
}
