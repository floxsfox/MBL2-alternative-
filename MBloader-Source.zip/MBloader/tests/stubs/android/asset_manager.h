#pragma once
#include <stddef.h>
#include <sys/types.h>
struct AAssetManager; struct AAsset;
extern "C" {
AAsset* AAssetManager_open(AAssetManager*, const char*, int);
int AAsset_read(AAsset*, void*, size_t);
off_t AAsset_seek(AAsset*, off_t, int);
off64_t AAsset_seek64(AAsset*, off64_t, int);
void AAsset_close(AAsset*);
const void* AAsset_getBuffer(AAsset*);
off_t AAsset_getLength(AAsset*);
off64_t AAsset_getLength64(AAsset*);
off_t AAsset_getRemainingLength(AAsset*);
off64_t AAsset_getRemainingLength64(AAsset*);
int AAsset_openFileDescriptor(AAsset*, off_t*, off_t*);
int AAsset_openFileDescriptor64(AAsset*, off64_t*, off64_t*);
int AAsset_isAllocated(AAsset*);
}
