#pragma once
// Stub minimal API preloader-android (hanya untuk uji di host).
#include <cstdlib>
#include <filesystem>
#include <string>
#include <pl/Logger.hpp>
namespace ll::mod { class NativeMod { public:
  static NativeMod* current() { static NativeMod m; return &m; }
  pl::log::Logger& getLogger() { static pl::log::Logger l; return l; }
  std::filesystem::path getModDir() const { return std::getenv("MBL_STUB_DIR"); }
  std::filesystem::path getConfigDir() const { return std::filesystem::path(std::getenv("MBL_STUB_DIR")) / "config"; }
  std::string getVersion() const { return "test"; }
}; }
#define PL_REGISTER_MOD(TYPE, INSTANCE_EXPR) static void* pl_stub_reg() { return &(INSTANCE_EXPR); }
