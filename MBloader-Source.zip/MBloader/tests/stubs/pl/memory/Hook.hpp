#pragma once
// Stub: hook "palsu" yang hanya mencatat detour supaya test bisa memanggilnya langsung.
#include <map>
namespace pl::memory {
using FuncPtr = void*;
enum class HookPriority : int { Highest = 0, High = 100, Normal = 200, Low = 300, Lowest = 400 };
inline std::map<void*, void*>& detourMap() { static std::map<void*, void*> m; return m; }
inline bool& failHooks() { static bool f = false; return f; }
class HookHandle { public:
  HookHandle() = default;
  HookHandle(FuncPtr t, FuncPtr d, FuncPtr* o, HookPriority = HookPriority::Normal) {
    if (!t || !d || !o || failHooks()) return;
    *o = t; detourMap()[t] = d; target = t; }
  HookHandle(HookHandle&& o) noexcept : target(o.target) { o.target = nullptr; }
  HookHandle& operator=(HookHandle&& o) noexcept { reset(); target = o.target; o.target = nullptr; return *this; }
  ~HookHandle() { reset(); }
  bool installed() const { return target != nullptr; }
  void reset() { if (target) { detourMap().erase(target); target = nullptr; } }
 private: void* target = nullptr; };
}
