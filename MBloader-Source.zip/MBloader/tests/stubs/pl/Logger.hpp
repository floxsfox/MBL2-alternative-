#pragma once
#include <string>
namespace pl::log { class Logger { public:
  template<class... A> void info(const char*, A&&...) {}
  template<class... A> void warn(const char*, A&&...) {}
  template<class... A> void error(const char*, A&&...) {}
  template<class... A> void debug(const char*, A&&...) {} }; }
