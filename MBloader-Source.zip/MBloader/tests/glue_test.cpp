// Uji integrasi glue hook di host dengan stub SDK + "libandroid" palsu.
//   g++ -std=c++20 -rdynamic -I tests/stubs -I src tests/glue_test.cpp src/mod/MBloaderMod.cpp src/core/PackIndex.cpp
#include "mod/MBloaderMod.h"

#include <android/asset_manager.h>
#include <pl/memory/Hook.hpp>

#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <string>
#include <vector>

namespace fs = std::filesystem;
static int gFail = 0;
#define CHECK(c) do { if (!(c)) { std::printf("GAGAL  %s:%d  %s\n", __FILE__, __LINE__, #c); ++gFail; } } while (0)

// ---- "libandroid" palsu: asset asli diawali pointer ala vtable
struct RealAsset { void *vtable; std::string data; size_t pos; };
static std::map<std::string, std::string> gApk;
static int gRealClosed = 0;

extern "C" {
AAsset *AAssetManager_open(AAssetManager *, const char *n, int) {
    auto it = gApk.find(n);
    if (it == gApk.end()) return nullptr;
    return reinterpret_cast<AAsset *>(new RealAsset{reinterpret_cast<void *>(0xABCDEF), it->second, 0});
}
int AAsset_read(AAsset *a, void *b, size_t c) {
    auto *r = reinterpret_cast<RealAsset *>(a);
    size_t n = std::min(c, r->data.size() - r->pos);
    std::memcpy(b, r->data.data() + r->pos, n); r->pos += n; return static_cast<int>(n);
}
off_t AAsset_seek(AAsset *, off_t, int) { return 0; }
off64_t AAsset_seek64(AAsset *, off64_t, int) { return 0; }
void AAsset_close(AAsset *a) { ++gRealClosed; delete reinterpret_cast<RealAsset *>(a); }
const void *AAsset_getBuffer(AAsset *a) { return reinterpret_cast<RealAsset *>(a)->data.data(); }
off_t AAsset_getLength(AAsset *a) { return static_cast<off_t>(reinterpret_cast<RealAsset *>(a)->data.size()); }
off64_t AAsset_getLength64(AAsset *a) { return static_cast<off64_t>(reinterpret_cast<RealAsset *>(a)->data.size()); }
off_t AAsset_getRemainingLength(AAsset *) { return 0; }
off64_t AAsset_getRemainingLength64(AAsset *) { return 0; }
int AAsset_openFileDescriptor(AAsset *, off_t *, off_t *) { return 99; }
int AAsset_openFileDescriptor64(AAsset *, off64_t *, off64_t *) { return 99; }
int AAsset_isAllocated(AAsset *) { return 0; }
}

template <typename Fn> static Fn det(Fn original) {
    auto &m = pl::memory::detourMap();
    auto it = m.find(reinterpret_cast<void *>(original));
    return it == m.end() ? nullptr : reinterpret_cast<Fn>(it->second);
}

static void put(const fs::path &p, const std::string &s) { fs::create_directories(p.parent_path()); std::ofstream(p, std::ios::binary) << s; }

int main() {
    const fs::path root = fs::temp_directory_path() / "mbl_glue_test";
    fs::remove_all(root);
    const fs::path prof = root / "Android/media/org.levimc.launcher/minecraft/prof";
    const fs::path games = prof / "games/com.mojang";
    const fs::path modDir = prof / "mods/mbloader";
    fs::create_directories(modDir);
    setenv("MBL_STUB_DIR", modDir.c_str(), 1);

    const std::string MAGIC("\x1a\xda\x11\x0a\x00\x00\x00\x00", 8);
    const std::string packFile = MAGIC + "PACK-SHADER-DATA";
    put(games / "resource_packs/Sh/manifest.json", "{\"header\":{\"uuid\":\"11111111-1111-1111-1111-111111111111\"}}");
    put(games / "resource_packs/Sh/renderer/materials/RenderChunk.material.bin", packFile);
    put(games / "resource_packs/Sh/renderer/materials/Bad.material.bin", std::string("XXXXXXXX") + "other-magic");
    put(games / "minecraftpe/global_resource_packs.json", "[{\"pack_id\":\"11111111-1111-1111-1111-111111111111\"}]");

    gApk["renderer/materials/RenderChunk.material.bin"] = MAGIC + "VANILLA";
    gApk["renderer/materials/Bad.material.bin"] = MAGIC + "VANILLA-BAD";
    gApk["renderer/materials/Sky.material.bin"] = MAGIC + "VANILLA-SKY";
    gApk["textures/terrain.png"] = "PNGDATA";

    auto &mod = MBloaderMod::instance();
    CHECK(mod.load());
    CHECK(fs::exists(modDir / "config/config.json"));
    CHECK(fs::is_directory(modDir / "override/renderer/materials"));

    // hook gagal -> enable() false & tidak ada hook tersisa
    pl::memory::failHooks() = true;
    CHECK(!mod.enable());
    CHECK(pl::memory::detourMap().empty());
    pl::memory::failHooks() = false;

    CHECK(mod.enable());
    CHECK(pl::memory::detourMap().size() == 13);

    auto hOpen = det(&AAssetManager_open); auto hRead = det(&AAsset_read); auto hClose = det(&AAsset_close);
    auto hBuf = det(&AAsset_getBuffer); auto hLen = det(&AAsset_getLength); auto hLen64 = det(&AAsset_getLength64);
    auto hRem = det(&AAsset_getRemainingLength64); auto hSeek = det(&AAsset_seek64); auto hAlloc = det(&AAsset_isAllocated);
    auto hFd = det(&AAsset_openFileDescriptor);
    CHECK(hOpen && hRead && hClose && hBuf && hLen && hLen64 && hRem && hSeek && hAlloc && hFd);

    // 1) material yang ada di pack -> diganti
    AAsset *a = hOpen(nullptr, "renderer/materials/RenderChunk.material.bin", 0);
    CHECK(a != nullptr);
    CHECK(hLen64(a) == static_cast<off64_t>(packFile.size()));
    CHECK(hLen(a) == static_cast<off_t>(packFile.size()));
    CHECK(std::memcmp(hBuf(a), packFile.data(), packFile.size()) == 0);
    CHECK(hAlloc(a) == 1);
    CHECK(hFd(a, nullptr, nullptr) == -1);
    char buf[64] = {0};
    CHECK(hRead(a, buf, 8) == 8 && std::memcmp(buf, MAGIC.data(), 8) == 0);
    CHECK(hRem(a) == static_cast<off64_t>(packFile.size() - 8));
    CHECK(hSeek(a, 0, 0) == 0);
    CHECK(hRead(a, buf, 64) == static_cast<int>(packFile.size()));
    int closedBefore = gRealClosed;
    hClose(a);
    CHECK(gRealClosed == closedBefore);

    // 2) material tanpa pengganti -> pointer asli, fungsi diteruskan ke asli
    AAsset *s = hOpen(nullptr, "renderer/materials/Sky.material.bin", 0);
    CHECK(s != nullptr);
    CHECK(hLen64(s) == static_cast<off64_t>((MAGIC + "VANILLA-SKY").size()));
    CHECK(hFd(s, nullptr, nullptr) == 99);
    int c0 = gRealClosed; hClose(s); CHECK(gRealClosed == c0 + 1);

    // 3) file non-material selalu asli
    AAsset *t = hOpen(nullptr, "textures/terrain.png", 0);
    CHECK(t != nullptr && hLen64(t) == 7);
    hClose(t);

    // 4) asset tidak ada di APK dan tidak ada di pack -> nullptr asli
    CHECK(hOpen(nullptr, "renderer/materials/Nothing.material.bin", 0) == nullptr);

    // 5) header beda: default tetap dipakai (hanya warning)
    AAsset *b = hOpen(nullptr, "renderer/materials/Bad.material.bin", 0);
    CHECK(b != nullptr && hLen64(b) == static_cast<off64_t>(std::string("XXXXXXXXother-magic").size()));
    hClose(b);

    // 6) disable -> pengalihan baru berhenti, FakeAsset lama tetap aman
    AAsset *keep = hOpen(nullptr, "renderer/materials/RenderChunk.material.bin", 0);
    CHECK(mod.disable());
    CHECK(hLen64(keep) == static_cast<off64_t>(packFile.size()));
    AAsset *after = hOpen(nullptr, "renderer/materials/RenderChunk.material.bin", 0);
    CHECK(after != nullptr && hLen64(after) == static_cast<off64_t>((MAGIC + "VANILLA").size()));
    hClose(after);
    // unload dengan FakeAsset tersisa: hook tidak dilepas
    CHECK(mod.unload());
    CHECK(pl::memory::detourMap().size() == 13);
    hClose(keep);
    CHECK(mod.unload());
    CHECK(pl::memory::detourMap().empty());

    if (gFail == 0) std::printf("UJI GLUE LULUS\n"); else std::printf("%d uji gagal\n", gFail);
    fs::remove_all(root);
    return gFail == 0 ? 0 : 1;
}
